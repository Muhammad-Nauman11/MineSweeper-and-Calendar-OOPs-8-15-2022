function Change(id)
{
    var elem=document.getElementById(id)
    elem.textContent="Dont Touch"
}

function generateRandomArr(length, max, min) {
    var resultsArr = [];
    for (let i = 0; i < length; i++) {
      const newNumber = Math.floor(Math.random() * (max - min)) + min;
      resultsArr.includes(newNumber) ? length += 1 : resultsArr.push(newNumber);
    }
    return resultsArr;
}
  

var gridHelper=[];
const numberOfRows=10;
const numberOfColumns=10;
var neighborsFinder=[ [ -1, -1, -(numberOfColumns + 1) ], [ -1, 0, -numberOfColumns ], [ -1, 1, -(numberOfColumns - 1) ], [ 0, 1, 1 ], [ 1, 1, numberOfColumns + 1 ], [ 1, 0, numberOfColumns ], [ 1, -1, numberOfColumns - 1 ], [ 0, -1, -1 ] ];


const bombLocations=generateRandomArr(numberOfColumns*numberOfRows/10,numberOfColumns*numberOfRows,0);
console.log("Before location")
for (var i=0;i< numberOfColumns*numberOfRows;i++)
{
    if(bombLocations.includes(i))
    {
        gridHelper[i]=-1
    }
    else
    {
        gridHelper[i]=0
    }
    
}


const width=50
var bomb='<img src="assets/Bomb.png" height="'+width.toString()+'px" width="'+width.toString()+'px" style="width:100%; height:75%; text-align:center; ">' 
var flag='<img src="assets/Flag.png" height="'+width.toString()+'px" width="'+width.toString()+'px" style="width:100%; height:75%; text-align:center; ">' 

for (var i=0; i<gridHelper.length;i++)
{
    const currentRow=i/numberOfColumns
    const currentColumn=i%numberOfColumns
    var neighborCounts=0
    if(gridHelper[i]!=-1){
            for (var j=0; j<neighborsFinder.length;j++)
            {
                const nextRow=currentRow+neighborsFinder[j][0]
                const nextColumn=currentColumn+neighborsFinder[j][1]
                if(0<nextRow<numberOfRows-1 && 0<nextColumn<numberOfColumns-1)
                {
                    const neighborLocation=i+neighborsFinder[j][2]
                    if(gridHelper[neighborLocation]==-1)
                    {
                        neighborCounts++;
                    }
                }
            }
        }
    else
    {
        neighborCounts=-1
    }
    gridHelper[i]=neighborCounts
    var parent=document.getElementById("minesweeper")
    var cell=document.createElement("button")
    cell.id=i.toString()
    cell.onmouseup=function(cell){Clicked(cell);}
    cell.style.backgroundColor="orange"
    cell.textContent=neighborCounts
    
    cell.style.width=width.toString()+"px"
    cell.style.height=width.toString()+"px"
    cell.classList.add("buttons")
    parent.style.width=(width*numberOfColumns).toString()+"px"
    parent.appendChild(cell)

}

function Clicked(obj)
{
    var cell=obj.target
    switch (obj.which) {
        case 1:
            // alert('Left Mouse button pressed.');
            LeftClickEvents(cell)
            break;
        case 2:
            // alert('Middle Mouse button pressed.');
            break;
        case 3:
            MarkAsFlagged(cell)
            break;
    }

}
function LeftClickEvents(cell)
{
    if(gridHelper[parseInt(cell.id,10)]==-1)
    {

        ShowBombs()
        alert("Game Over!")
    }
    else
    {
        DisplayContent(cell)
    }
}

function DisplayContent(cell)
{
    const index=parseInt(cell.id)
    const currentRow=index/numberOfColumns
    const currentColumn=index%numberOfColumns
    if (gridHelper[index]==0 && !cell.style.disabled)
    {
        cell.style.backgroundColor="yellow"
        cell.style.disabled = true;
        for(var i=0;i<neighborsFinder.length;i++)
        {
            const nextRow=currentRow+neighborsFinder[i][0]
            const nextColumn=currentColumn+neighborsFinder[i][1]
            const nextIndex=index+neighborsFinder[i][2]
            if(0<=nextRow<=numberOfRows-1 && 0<=nextColumn<=numberOfColumns-1)
            {
                const nextCell=document.getElementById(nextIndex.toString())
                DisplayContent(nextCell)
            }
    
    
        }
    }


    else if (gridHelper[index]!=-1){
        cell.style.backgroundColor="blue"
        cell.textContent=gridHelper[index]
        return;
    }

}

function ShowBombs()
{
    for (var i=0;i< bombLocations.length;i++)
    {
        const id=bombLocations[i].toString()
        var cell=document.getElementById(id)
        cell.innerHTML =bomb

    }
}
function MarkAsFlagged(cell)
{
    var imgList=cell.getElementsByTagName('img')
    if( imgList.length> 0 || cell instanceof HTMLImageElement)
    {
        // alert("tes ut ")
        imgList=cell.parentNode.getElementsByTagName('img')
        for(var i=0;i<imgList.length;i++)
        {
            // alert("tes ut tr")
            imgList[i].parentNode.removeChild(imgList[i]);
        }

    }
    else
    {
        // cell.insertAdjacentHTML('beforeend', flag);
        cell.innerHTML =flag;
    }
}

