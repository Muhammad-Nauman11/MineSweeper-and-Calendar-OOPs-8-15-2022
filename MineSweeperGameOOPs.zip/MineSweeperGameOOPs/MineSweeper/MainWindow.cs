﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
//using System.IO;

namespace MineSweeper
{
    public partial class MainWindow : Form
    {
        public Minesweeper mineSweeper { get; set; }//minesweeper's object with grid and mines location

        //String Array Data Types
        public string[] gameTypes = { "Easy", "Medium", "Hard" };
        public string[] timerTypes = {"Count Up","Count Down"};
        
        //Images Objects
        public Images timerImage = new Images(@"assets\Timer.png");// Timer's Image
        public Images bombImage = new Images(@"assets\Bomb.png");// Bomb's Image
        public Images flagImage = new Images(@"assets\Flag.png");// Flag's Image

        //Integers Data Types
        public int numberOfRows { get; set; }// number of cells in a row
        public int numberOfColumns { get; set; }// number of cells in a column
        public int gameWidth { get; set; }//width of minesweeper game's grid
        public int gameHeight { get; set; }//height of minesweeper game's grid
        public int timeInSeconds { get; set; }

        //strings Data Types
        public string gameState;//To know if game ended and how it ended i.e whether game over or game finish
        public string timerType { get; set; }//type of timer used in game like up or down etc
        public string gameType { get; set; }//type of game easy hard etc


        public MainWindow()
        {
            InitializeComponent();
            cmbTimerType.SelectionLength = 0;//it didn't help at all
        }
            private void MainWindow_Load(object sender, EventArgs e)
        {
            WidgetContainer.Size =this.Size;//Making the size of widget container equal to size of window
            StatusPanel.Width = this.Width;//Making Status Panel width equal to main windows width
            foreach (string gameType in gameTypes) //adding the gametypes strings to the menu of combobox of game type
            {
                cmbGameType.Items.Add(gameType);
            }
            foreach (string timerType in timerTypes)//adding the timertypes strings to the menu of combobox of time type
            {
                cmbTimerType.Items.Add(timerType);
            }
            gameType = gameTypes[1];
            timerType = timerTypes[0];
            cmbGameType.Text =gameType;//selecting medium as by default game type
            cmbTimerType.Text = timerType;//selecting up counter as by defalt timer type


            pictureFlag.Image =flagImage.ResizeImage(pictureFlag.Size);//lblFlagFitImage;//flag image along with number of flags
            pictureTimer.Image = timerImage.ResizeImage(pictureTimer.Size);//displaying timer image along with timer
            StartGame();//starting the game with default values
        }


        public void StartGame() 
        {

            //Implementing game type
            gameType = cmbGameType.Text;
            switch (gameType) //each type will have different number of rows and columns
            {
                case "Easy":
                    numberOfRows = 20;
                    numberOfColumns = 10;
                    timeInSeconds =10*60;//10 minutes
                    break;
                case "Medium":
                    numberOfRows = 20;
                    numberOfColumns = 25;
                    timeInSeconds = 20*60;//20 minutes
                    break;
                case "Hard":
                    numberOfRows = 25;
                    numberOfColumns = 40;
                    timeInSeconds = 30*60;//30 minutes
                    break;
            }


            //assigning value of timer type
            timerType = cmbTimerType.Text;
            switch (timerType)
            {
                case "Count Up":
                    timeInSeconds = 0;
                    break;
                case "Count Down":
                    break;
            }

            //displaying time in timer label
            lblTimer.Text = $"{timeInSeconds / 60:00}:{timeInSeconds % 60:00}";

            
            //displaying number of flags and they will be equal to number of bombs
            
            int numberOfBombs = numberOfColumns*numberOfRows/8;//Calculating number of bombs depending upon the type of game
            lblNumberOfFlag.Text =$"{numberOfBombs}";

            DisplayBoard();

        }

        //Displaying game board on the mineSweeper
        public void DisplayBoard() 
        {

            int windowX, windowY, windowW, windowH;
            windowX = Location.X;
            windowY = Location.Y;
            windowW = Size.Width;
            windowH = Size.Height;

            mineSweeper = new Minesweeper(numberOfRows,numberOfColumns,new Size(windowW*9/10,windowH*8/10),flagImage, bombImage); 
            WidgetContainer.Controls.Add(mineSweeper);//adding mineSweeper to main windows widget container
            mineSweeper.OnStatusChange += () => { UpdateStatusBar(); };          
            mineSweeper.OnGameEnd += () => { DisplayMessage(); };

            mineSweeper.RunGame();
            Point gameLocation = new Point(windowX + windowW / 2 - mineSweeper.Size.Width / 2, windowY + windowH / 2 - mineSweeper.Size.Height / 2);//bringing game panel to center of the window
            mineSweeper.Location = gameLocation;
            gameTimer.Start();//starting the timer


        }





        //display different messages depending upon the type of the game end
        public void DisplayMessage() 
        {
            string message="Game is running" ;
            switch(mineSweeper.gameState)
            {
                case "Complete":
                    message = "Congratulations, you have sweeped all the mines.";
                    break;
                case "Over":
                    message = "Bombs blast. Game Over";
                    break;
                case "Time Out":
                    message = "Time has Ended. Game Over";
                    break;
            }

            MessageBox.Show(message);
            mineSweeper.Controls.Clear();//clear previous game data 
            mineSweeper.Dispose();
            StartGame();//start new game
            
        
        }

        private void cmbGameType_SelectedIndexChanged(object sender, EventArgs e)
        {//every time an item on gametype combobox is clicked new game with updated features will start
            if (gameType!=cmbGameType.Text) 
            {
                mineSweeper.Controls.Clear();
                mineSweeper.Dispose();
                StartGame();
            }

        }

        private void cmbTimerType_SelectedIndexChanged(object sender, EventArgs e)
        {//every time an item on timertype combobox is clicked new game with updated features will start
            if (timerType != cmbTimerType.Text)
            {
                mineSweeper.Controls.Clear();
                mineSweeper.Dispose();
                StartGame();
            }

        }

        public void UpdateStatusBar() 
        {
            lblNumberOfFlag.Text = mineSweeper.numberOfFlags + "";
        }
        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (mineSweeper.gameStart && mineSweeper.gameState == "Running") 
            {

                if (timerType == "Count Up")
                {
                    //for up count timer
                    timeInSeconds++;
                }
                else 
                {
                    //for down count timer
                    timeInSeconds--;
                    if (timeInSeconds <= 0)
                    {
                        mineSweeper.gameState = "Time Out";
                        DisplayMessage();
                    }

                }
                lblTimer.Text = $"{timeInSeconds/60:00}:{timeInSeconds%60:00}";
            }
        }
    }





    //Minesweeper game class
    public class Minesweeper : Panel
    {
        //Color object
        public Color colorOfCell = Color.FromArgb(0, 180, 0);//Initial color of cell

        //Objects of Images class
        public Images flag { get; set; }//flag's image
        public Images bomb { get; set; }//bomb's image

        //boolean Data types
        public bool gameStart { get; set; }//checking if game is started after first time any cell of grid is clicked
        
        //string Data types
        public string gameState { get; set; }//variable to know if game ended and how it ended else it will be running

        //Integers Data types
        public int cellsWidth { get; set; }
        public int cellsHeight { get; set; }
        public int numberOfRows { get; set; }// number of rows
        public int numberOfColumns { get; set; }// number of columns
        public int numberOfBombs { get; set; }//number of bombs in a game
        public int gameWidth { get; set; }//width of game panel
        public int gameHeight { get; set; }//height of game panel
        public int numberOfFlags { get; set; }//number of flags
        //Integers Arrays
        public int[] minesweeperBoard { get; set; }  //One dimensional array to store data for grid of minesweepr
        public int[] bombLocations { get; set; }//one dimensional array to holds the locations or indices of bombs in grid
        public int[,] neighborFinder { get; set; }//2D array to help in finding neighbours of current cell

        //Delegates and events
        public delegate void StatusChange();
        public event StatusChange OnStatusChange;//Invoked when flags number changes
        public event StatusChange OnGameEnd;//Invoked when game ended either by game over or completion


        //Minesweeper Parametrized Constructor
        public Minesweeper(int numberofrows,int numberofcolumns,Size size,Images flagImage, Images bombImage)
        {
            numberOfRows = numberofrows;
            numberOfColumns = numberofcolumns;
            Size = size;
            cellsWidth =Size.Width / numberOfColumns;//calculating cell width
            cellsHeight = Size.Height / numberOfRows;//calculating cell height
            if (cellsWidth > cellsHeight)
            {
                cellsWidth = cellsHeight;
            }
            else 
            {
                cellsHeight = cellsWidth;
            }

            gameStart = false;
            gameState = "Running";

            flag = flagImage;
            flag.ResizeImage(new Size(cellsWidth,cellsHeight));
            bomb = bombImage;
            bomb.ResizeImage(new Size(cellsWidth, cellsHeight));
            numberOfBombs = numberOfFlags=numberOfColumns * numberOfRows / 8;//Calculating number of bombs depending upon the type of game
            neighborFinder = new int[,] { { -1, -1, -(numberOfColumns + 1) }, { -1, 0, -numberOfColumns }, { -1, 1, -(numberOfColumns - 1) }, { 0, 1, 1 }, { 1, 1, numberOfColumns + 1 }, { 1, 0, numberOfColumns }, { 1, -1, numberOfColumns - 1 }, { 0, -1, -1 } };


            GenerateBoard();
        }

        //Run the game by calling generate grid method
        public void RunGame()
        {
            GeneratingGrid();
        }


        //Generating the data for minesweeper board or grid
        private void GenerateBoard() 
        {
            minesweeperBoard = new int[numberOfRows * numberOfColumns];

            //Bombs Locattions
            var randomGenerator = new Random();
            bombLocations = Enumerable.Range(0, numberOfRows * numberOfColumns).OrderBy(randomNum => randomGenerator.Next()).Take(numberOfBombs).ToArray();


            //Board Generation
            for (int iCell = 0; iCell < numberOfRows * numberOfColumns; iCell++)
            {
                if (bombLocations.Contains(iCell))
                {
                    minesweeperBoard[iCell] = -1;
                }
                else
                {
                    minesweeperBoard[iCell] = 0;
                }
            }


            //Preparing board to mark locations of cells that have bomb neighbors

            for (int iCell = 0; iCell < numberOfRows * numberOfColumns; iCell++)
            {
                if (minesweeperBoard[iCell] != -1)
                {
                    int row, col, rowCurrent, colCurrent, nextIndex;
                    rowCurrent = iCell / numberOfColumns;
                    colCurrent = iCell % numberOfColumns;


                    for (int iNebIndex = 0; iNebIndex < neighborFinder.Length / 3; iNebIndex++)
                    {
                        row = rowCurrent + neighborFinder[iNebIndex, 0];//finding row of neighbour
                        col = colCurrent + neighborFinder[iNebIndex, 1];//finding column of neighbour

                        if (0 <= col && col <= numberOfColumns - 1 && 0 <= row && row <= numberOfRows - 1)
                        {

                            nextIndex = iCell + neighborFinder[iNebIndex, 2];
                            if (minesweeperBoard[nextIndex] == -1)
                            {
                                minesweeperBoard[iCell] += 1;//if a  cell has bomb its value will be increased by one so for every bombed neighbour value will be incremented
                            }
                        }
                    }
                }
            }
        }

        //Generating graphical items for the grid of minesweeper
        public void GeneratingGrid() 
        {

            //making width and height of boxes equal
            if (cellsWidth < cellsHeight)
            {
                cellsHeight = cellsWidth;
            }
            else
            {
                cellsWidth = cellsHeight;
            }


            for (int iCell = 0; iCell < minesweeperBoard.Length; iCell++) //looping through the minesweeperBoard to make that many buttons
            {

                Cell btnCell = new Cell($"{minesweeperBoard[iCell]}", colorOfCell, new Size(cellsWidth, cellsHeight), new Point((iCell % numberOfColumns) * cellsWidth, (iCell / numberOfColumns) * cellsHeight));
                btnCell.OnLeftClick += () => { ShowCellsContent(btnCell); };
                btnCell.OnRightClick += () => { MarkAsFlagged(btnCell); };
                Controls.Add(btnCell);

            }
            Size = new Size(numberOfColumns * cellsWidth, numberOfRows * cellsHeight);//Resizing the minesweeper gamepanel to fit to the size of grid
        }

        //To mark or unmark the cell as flagged
        public void MarkAsFlagged(Cell btnCell) 
        {
            gameStart = true;
            if (btnCell.FlatStyle != FlatStyle.Flat) 
            { 
                if (btnCell.Image == null)// && Convert.ToInt32(lblNumberOfFlag.Text) != 0)
                {
                    if (numberOfFlags>0) 
                    { 
                        btnCell.Image = flag.image;//display flage on current cell or button
                        numberOfFlags --;

                    }
                }
                else
                {
                    btnCell.Image = null;
                    numberOfFlags++;
                }
                OnStatusChange.Invoke();//Every time right marking or unmarking is done the flags number status of the game will be changed

            }
        }

        //To show what's the content inside the cell
        public void ShowCellsContent(Cell btnCell) 
        {
            gameStart = true;

            //Button btnCell = sender as Button;
            if (gameState == "Running" && btnCell.FlatStyle!=FlatStyle.Flat && btnCell.Image==null) //if game is running only then gamer can click the buttons or cells
            {
                gameStart = true;//on first click this will be set true and will remain true til end of game

                if (btnCell.Name == "-1") //if clicked button is bombed button
                {


                    foreach (int bombLocation in bombLocations) //loop through the minesweeperBoard and find where are bombs and display them
                    {
                        Cell btnBombCell = Controls[bombLocation] as Cell;
                        if (btnBombCell.Name == "-1")
                        {

                            btnBombCell.Image = bomb.image;
                        }


                    }
                    gameState = "Over";
                    if (gameState == "Over")
                    {
                        OnGameEnd.Invoke();//Proceeding towards the message of game over and new game
                    }



                }
                else
                {
                    //if clicked cell is not bomb then change its flat property and also propagate to find nearest neighbours without bombs
                    ChangeCell(btnCell);
                    gameState = "Complete";
                    foreach (Button btnCheckEnd in Controls) //checking if all cells other than bombed are visited or buttons are flat
                    {
                        if (btnCheckEnd.Name != "-1" && btnCheckEnd.FlatStyle != FlatStyle.Flat) //if a single unbombed button is not flat then game is not end or complete
                        {
                            gameState = "Running";
                            break;
                        }
                    }

                    
                    if (gameState == "Complete")
                    {
                        OnGameEnd.Invoke();//Proceeding towards the message of game Completion and new game
                    }                   
                }
            }    
        }

        //
        public void ChangeCell(Cell btnCell)
        {

            Color colorOfCell = Color.FromArgb(128, 64, 0);
            Color textColor = Color.FromArgb(0, 0, 255);
            int numInsideCell = Convert.ToInt32(btnCell.Name);


            //Assigning differnt colors to different cells depending upon how many bomb neibors they have
            switch (numInsideCell)
            {
                case 0:
                    colorOfCell = Color.FromArgb(200, 200, 180);
                    break;
                case 1:
                    colorOfCell = Color.FromArgb(185, 153, 100);
                    textColor = Color.FromArgb(0, 155, 0);
                    break;
                case 2:
                    colorOfCell = Color.FromArgb(210, 125, 45);
                    textColor = Color.FromArgb(0, 0, 255);
                    break;
                case 3:
                    colorOfCell = Color.FromArgb(184, 115, 51);
                    textColor = Color.FromArgb(25, 50, 150);
                    break;
                case 4:
                    colorOfCell = Color.FromArgb(204, 119, 34);
                    textColor = Color.FromArgb(155, 50, 50);
                    break;
                case 5:
                    colorOfCell = Color.FromArgb(192, 64, 0);
                    textColor = Color.FromArgb(100, 150, 140);
                    break;
                case 6:
                    colorOfCell = Color.FromArgb(123, 63, 0);
                    textColor = Color.FromArgb(200, 0, 50);
                    break;
                case 7:
                    colorOfCell = Color.FromArgb(165, 42, 42);
                    textColor = Color.FromArgb(255, 50, 50);
                    break;
                case 8:
                    colorOfCell = Color.FromArgb(240, 230, 140);
                    textColor = Color.FromArgb(255, 0, 0);
                    break;
                case -1:
                    colorOfCell = Color.FromArgb(0, 120, 0);
                    break;
            }

            //To check if cell is bombed
            if (numInsideCell != -1)
            {
                if (btnCell.Image == null)//Only open the cell if it is not flagged or not containing image of flag
                { 
                    btnCell.FlatStyle = FlatStyle.Flat;
                    btnCell.BackColor = colorOfCell;
                }

                int row, col, rowCurrent, colCurrent, nextIndex;
                int btnNumber = Convert.ToInt32(btnCell.Parent.Controls.IndexOf(btnCell));//btnNumber is the index of button and it will be same as the index of element at that index in minesweeperBoard                
                rowCurrent = btnNumber / numberOfColumns;//by dividing will convert a one D index to row of 2d array
                colCurrent = btnNumber % numberOfColumns;//by taking remainder will convert a one D index to column of 2d array

                //Only go towards recursive opening of cells if the clicked cell is empty or has no bombed neighbour
                if (minesweeperBoard[btnNumber] == 0)
                {
                    for (int iNebIndex = 0; iNebIndex < neighborFinder.Length / 3; iNebIndex++)
                    {
                        row = rowCurrent + neighborFinder[iNebIndex, 0];
                        col = colCurrent + neighborFinder[iNebIndex, 1];

                        if (0 <= col && col <= numberOfColumns - 1 && 0 <= row && row <= numberOfRows - 1)
                        {

                            nextIndex = btnNumber + neighborFinder[iNebIndex, 2];
                            Cell nextBtnCell = btnCell.Parent.Controls[nextIndex] as Cell;
                            if (nextBtnCell.FlatStyle != FlatStyle.Flat)
                            {
                                //recursively propagate through the cells grid or board to know where bombs and numbered cells are located
                                ChangeCell(nextBtnCell);
                            }


                        }

                    }

                }
                else
                {
                    if (btnCell.Image == null) 
                    { 
                        btnCell.Text = $"{minesweeperBoard[btnNumber]}";
                        btnCell.ForeColor = textColor;
                        btnCell.FlatAppearance.BorderColor = Color.Black;
                        btnCell.Font = new Font(btnCell.Font.FontFamily, btnCell.Size.Height / 3, FontStyle.Bold);
                    }
                }
            }


        }

    }

    //Cells of Minesweeper
    public class Cell:Button
    {
        public delegate void CellChanged();
        public event CellChanged OnLeftClick;
        public event CellChanged OnRightClick;
        public Cell(string name,Color color,Size size,Point location) 
        {
            Name = name;
            MouseUp += Cell_MouseUp;
            FlatStyle = FlatStyle.Popup;
            BackColor = color;
            Size = size;
            Location = location;
        }

        private void Cell_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                OnLeftClick.Invoke();
            }
            else 
            {
                OnRightClick.Invoke();
            }

            
        }

    }

    //Customized image class
    public class Images    
    {
        public Image image { get; set; }
        public  Images(string imagepath)
        {
            image=Image.FromFile(imagepath);
        }

        public Image ResizeImage( Size size)
        {
            Image imgToResize = image;
            //Get the image current width  
            int sourceWidth = imgToResize.Width;
            //Get the image current height  
            int sourceHeight = imgToResize.Height;
            float nPercent = 0;
            float nPercentW = 0;
            float nPercentH = 0;
            //Calulate  width with new desired size  
            nPercentW = ((float)size.Width / (float)sourceWidth);
            //Calculate height with new desired size  
            nPercentH = ((float)size.Height / (float)sourceHeight);
            if (nPercentH < nPercentW)
                nPercent = nPercentH;
            else
                nPercent = nPercentW;
            //New Width  
            int destWidth = (int)(sourceWidth * nPercent);
            //New Height  
            int destHeight = (int)(sourceHeight * nPercent);
            Bitmap bitMap = new Bitmap(destWidth, destHeight);
            Graphics graphicsOfImage = Graphics.FromImage((Image)bitMap);
            graphicsOfImage.InterpolationMode = InterpolationMode.HighQualityBicubic;
            // Draw image with new width and height  
            graphicsOfImage.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            graphicsOfImage.Dispose();
            image= (Image)bitMap;
            return (Image)bitMap;
        }
    }
}

