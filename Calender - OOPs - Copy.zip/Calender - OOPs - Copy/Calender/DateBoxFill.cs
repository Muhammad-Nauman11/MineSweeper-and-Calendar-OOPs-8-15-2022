﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Calender
{
    //Parent Date Box Class
    public partial class DateBoxFill : UserControl
    {
        public int dateOfDay { get; set;}
        public DateBoxFill(Point location, int dateOftheDay)
        {
            InitializeComponent();
            Location = location;
            dateOfDay = dateOftheDay;
            ShowDateOfDay(dateOftheDay);


        }

        private void DateBoxFill_Load(object sender, EventArgs e)
        {
            
        }
        private void DateBoxFill_MouseIn(object sender, EventArgs e)
        {
            BackColor = Color.Red;
        }
        public void ShowDateOfDay(int numDay)
        {
            btnDateFill.Text = numDay+"";//Display Date inside the datebox button

        }
    }


    //class of objects to display dates that lies in current month
    public class EnabledBox: DateBoxFill 
    {
        public delegate void MarkEvented();
        public event MarkEvented OnEventAddition;//To help in event Addition
        public event MarkEvented OnEventDeletion;//To help in event Deletion

        public int month { get; set; }
        public int year { get; set; }

        public bool IsCurrentDate = false;

        public EnabledBox(Point location, int dateOftheDay,int iMonth,int iYear) : base( location, dateOftheDay)
        {
            month = iMonth;
            year = iYear;
            btnDateFill.Click += new EventHandler(btnDateFill_Click);
            MarkAsEvented();
            if (new DateTime(year, month, dateOftheDay) == DateTime.Now.Date) 
            {

                MarkCurrentDate();//Bordering the current date
             
            }

        }

        //Marking all the events that lies in a month
        public void MarkAsEvented()
        {
            string eventDate = $"{month:00}/{dateOfDay:00}";
            if (Calendar.eventsData.ContainsKey(eventDate))
            {
                ttpDescription.SetToolTip(Controls[0], Calendar.eventsData[eventDate]);
                btnDateFill.BackColor = Color.FromArgb(255, 0, 0);//Making box red
                btnDateFill.ForeColor = Color.Yellow;
            }


        }

        //Unmark event when it is deleted
        public void UnmarkAsEvented() 
        {
            btnDateFill.BackColor = Color.FromArgb(60, 60, 60);
            if (!IsCurrentDate) 
            {
                btnDateFill.ForeColor = Color.White;
                ttpDescription.RemoveAll();
            }
            
        }

        //To mark current date with highlighted borders
        public void MarkCurrentDate()
        {
            IsCurrentDate = true;
            btnDateFill.FlatAppearance.BorderSize = 3;
            btnDateFill.FlatAppearance.BorderColor = btnDateFill.ForeColor = Color.Yellow;

        }
        private void btnDateFill_Click(object sender, EventArgs e)
        {

            bool keyExist = false;

            EventSavingForm EventNow = new EventSavingForm(dateOfDay,month,year);//Creating the 
            EventNow.OnEventAdditions += () => { EventAdd(); };
            EventNow.OnEventDeletions += () => { EventDelete(); };

            foreach (var item in Calendar.eventsData)
            {
                if (item.Key == $"{month:00}/{Convert.ToInt32(dateOfDay):00}")
                {
                    keyExist = true;
                    break;

                }

            }
            if (keyExist)
            {
                EventNow.txtEvent.Text = Calendar.eventsData[$"{month:00}/{Convert.ToInt32(dateOfDay):00}"];

            }
            EventNow.ShowDialog();
        }

        //On Addition of Event Mark the datebox with red color
        public void EventAdd() 
        {
            MarkAsEvented();
            OnEventAddition.Invoke();
        }

        //On Delete Event Unmark the datebox
        public void EventDelete() 
        {
            UnmarkAsEvented();
            OnEventDeletion.Invoke();
        }
    }



    //class of objects to display dates that lies in Previous or Next month but are displayed on calendar along with current month
    class DisabledBox : DateBoxFill
    {

        public DisabledBox( Point location,int dateOftheDay) : base(location, dateOftheDay)
        {
            btnDateFill.EnabledChanged += new EventHandler(Buttons_EnabledChanged);
            Enabled = false;//Disabling the button to make them behave like label
        }

        private void Buttons_EnabledChanged(object sender, EventArgs e)
        {
            btnDateFill.FlatAppearance.BorderSize = 0;
            btnDateFill.ForeColor = !Enabled ? Color.LightGray : Color.Red;
            btnDateFill.BackColor = Color.FromArgb(40,40,40);
        }
    }
}
