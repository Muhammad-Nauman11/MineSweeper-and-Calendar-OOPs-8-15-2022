﻿using System;
using System.Windows.Forms;

namespace Calender
{
    public partial class EventSavingForm : Form
    {
        public delegate void MarkEvented();
        public event MarkEvented OnEventAdditions;//Invoke Addition to Text file
        public event MarkEvented OnEventDeletions;//Invoke Deletion From Text file

        //Date parameters of selected box
        public int dateOfDay;
        public int month;
        public int year;



        //Constructor
        public EventSavingForm(int day,int iMonth, int iYear)
        {
            dateOfDay = day;
            month = iMonth;
            year = iYear;
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void EventSavingForm_Load(object sender, EventArgs e)
        {
            txtDate.Text = dateOfDay + "/" + month + "/" + year;
            txtDate.ReadOnly = true;//Don't allow user to change date manually

        }

        //Add event to events dictionary and help in save
        private void btnSave_Click(object sender, EventArgs e)
        {

            string descriptions = txtEvent.Text;
            if (descriptions!="") 
            {
                Calendar.eventsData[$"{month:00}/{dateOfDay:00}"] = $"{descriptions}";
                OnEventAdditions.Invoke();
            }
            Close();

        }

        //Delete event to events dictionary and help in save
        private void btnDelete_Click(object sender, EventArgs e)
        {

            //string descriptions = txtEvent.Text;
            Calendar.eventsData.Remove($"{month:00}/{dateOfDay:00}");
            OnEventDeletions.Invoke();         
            Close();

        }
        private void txtEvent_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
